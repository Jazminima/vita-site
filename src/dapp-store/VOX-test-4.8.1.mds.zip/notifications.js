/**
 * Notification Functions
 * Dependencies:
 * - MDS from Minima
 * - USER_PUBKEY from service.js
 * - getNotificationPreferences from sql.js
 * - getPostByPostId from sql.js
 * - getPollWithOptions from sql.js
 * - addNotification from sql.js
 */

function notifyPost(postUserName, postUserPubkey, postMsg, postId) {
  MDS.comms.solo(
    JSON.stringify({ target: "client", event: "NEWPOST" }),
    function (resp) {
      getNotificationPreferences(USER_PUBKEY, function (prefs) {
        let notificationMsg = `${postUserName} posted: ${postMsg}`;
        if (notificationMsg.length > 40) {
          notificationMsg = notificationMsg.substring(0, 40) + "...";
        }
        getUser(postUserPubkey, function (user) {
          if (Number(user.rows[0].IS_SUBSCRIBED)) {
            if (Number(prefs.NOTIFY_ON_POST)) {
              MDS.notify(notificationMsg);
              // Store notification in database
              addNotification(USER_PUBKEY, "POST", notificationMsg, postId);
            }
          }
        });
      });
    }
  );
}

function notifyReply(parentPostId, replyUserName, replyMsg) {
  MDS.comms.solo(
    JSON.stringify({ target: "client", event: "NEWREPLY" }),
    function (resp) {
      getNotificationPreferences(USER_PUBKEY, function (prefs) {
        if (Number(prefs.NOTIFY_ON_REPLY)) {
          getPostByPostId(parentPostId, function (post) {
            if (post.count > 0) {
              const originalPost = post.rows[0];
              if (originalPost.USER_PUBKEY === USER_PUBKEY) {
                let notificationMsg = `${replyUserName} replied to your post: ${replyMsg}`;
                if (notificationMsg.length > 40) {
                  notificationMsg = notificationMsg.substring(0, 40) + "...";
                }
                MDS.notify(notificationMsg);
                // Store notification in database
                addNotification(
                  USER_PUBKEY,
                  "REPLY",
                  notificationMsg,
                  parentPostId
                );
              }
            }
          });
        }
      });
    }
  );
}

function notifyUpvote(recipientPubkey, tipAmount, postId) {
  MDS.comms.solo(
    JSON.stringify({
      target: "client",
      event: "NEWTIP",
      recipientPubkey: recipientPubkey,
    }),
    function (resp) {
      if (recipientPubkey === USER_PUBKEY) {
        getNotificationPreferences(USER_PUBKEY, function (prefs) {
          const upvoteWord = Math.abs(tipAmount) === 1 ? "upvote" : "upvotes";
          const upvoteSign = tipAmount > 0 ? "+" : "";
          const tipValue = (tipAmount / 20).toFixed(2);
          let notificationMsg = `Your post received ${upvoteSign}${tipAmount} ${upvoteWord} and your tip was ${tipValue} MINIMA`;
          if (Number(prefs.NOTIFY_ON_UPVOTE)) {
            MDS.notify(notificationMsg);
            // Store notification in database
            addNotification(USER_PUBKEY, "UPVOTE", notificationMsg, postId);
          }
        });
      }
    }
  );
}

function notifyPoll(pollUserName, pollUserPubkey, question, pollId) {
  MDS.comms.solo(
    JSON.stringify({ target: "client", event: "NEWPOST" }),
    function (resp) {
      getNotificationPreferences(USER_PUBKEY, function (prefs) {
        let notificationMsg = `${pollUserName} created a poll: ${question}`;
        if (notificationMsg.length > 40) {
          notificationMsg = notificationMsg.substring(0, 40) + "...";
        }
        getUser(pollUserPubkey, function (user) {
          if (Number(user.rows[0].IS_SUBSCRIBED)) {
            if (Number(prefs.NOTIFY_ON_POST)) {
              MDS.notify(notificationMsg);
              // Store notification in database
              addNotification(USER_PUBKEY, "POLL", notificationMsg, pollId);
            }
          }
        });
      });
    }
  );
}

function notifyPollVote(pollId) {
  MDS.comms.solo(
    JSON.stringify({ target: "client", event: "NEWPOST" }),
    function (resp) {
      getPollWithOptions(pollId, function (pollData) {
        if (pollData.status && pollData.poll) {
          const poll = pollData.poll;
          if (poll.USER_PUBKEY === USER_PUBKEY) {
            getNotificationPreferences(USER_PUBKEY, function (prefs) {
              if (Number(prefs.NOTIFY_ON_UPVOTE)) {
                const notificationMsg = "Someone voted on your poll";
                MDS.notify(notificationMsg);
                // Store notification in database
                addNotification(
                  USER_PUBKEY,
                  "POLL_VOTE",
                  notificationMsg,
                  pollId
                );
              }
            });
          }
        }
      });
    }
  );
}

function notifyRepost(repostUserName, originalAuthorPubkey, postId) {
  MDS.comms.solo(
    JSON.stringify({ target: "client", event: "NEWPOST" }),
    function (resp) {
      getNotificationPreferences(USER_PUBKEY, function (prefs) {
        if (originalAuthorPubkey === USER_PUBKEY) {
          try {
            let notificationMsg = `${repostUserName} reposted your post`;
            if (Number(prefs.NOTIFY_ON_REPOST)) {
              MDS.notify(notificationMsg);
              // Store notification in database
              addNotification(USER_PUBKEY, "REPOST", notificationMsg, postId);
            }
          } catch (error) {
            MDS.log("Error parsing repost notification: " + error);
          }
        }
      });
    }
  );
}

function notifyReaction(postId, reactorName, emoji) {
  MDS.comms.solo(
    JSON.stringify({ target: "client", event: "NEWPOST" }),
    function (resp) {
      getPostByPostId(postId, function (post) {
        if (post.count > 0) {
          const originalPost = post.rows[0];
          if (originalPost.USER_PUBKEY === USER_PUBKEY) {
            getNotificationPreferences(USER_PUBKEY, function (prefs) {
              if (Number(prefs.NOTIFY_ON_UPVOTE)) {
                let notificationMsg = `${reactorName} reacted with ${emoji} to your post`;
                MDS.notify(notificationMsg);
                // Store notification in database
                addNotification(
                  USER_PUBKEY,
                  "REACTION",
                  notificationMsg,
                  postId
                );
              }
            });
          }
        }
      });
    }
  );
}

function notifyPayment(senderName, amount, description, coinId) {
  updateTotalReceivedPayments(USER_PUBKEY, amount, function(sqlResp) {
    if (sqlResp.status) {
      const notificationText = senderName
        ? `@${senderName} sent you ${amount} MINIMA${
            description ? ": " + description : ""
      }`
    : `You received ${amount} MINIMA anonymously${
        description ? ": " + description : ""
      }`;
    getNotificationPreferences(USER_PUBKEY, function (prefs) {
      if (Number(prefs.NOTIFY_ON_PAYMENT)) {
        MDS.notify(notificationText);
          addNotification(USER_PUBKEY, "PAYMENT", notificationText, coinId);
        }
      });
    }
  });
}
