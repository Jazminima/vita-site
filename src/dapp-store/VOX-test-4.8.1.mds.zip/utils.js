/**
 * Utility Functions
 * No dependencies other than MDS
 */

function logWithLevel(msg, level) {
    if (typeof level === "undefined") level = "error";
    if (
        typeof MDS !== 'undefined' &&
        MDS.logging &&
        MDS.logLevels &&
        MDS.logLevels[level] !== undefined &&
        MDS.logLevels[level] >= MDS.logLevels[MDS.logLevel]
    ) {
        MDS.log(msg);
    }
}

function checkTxn(msg) {
  if (msg.data.coin.tokenid != "0x00") {
    logWithLevel("Message not sent as Minima.. ! " + msg.data.coin.tokenid, "error");
    return false;
  } else if (stripBrackets(msg.data.coin.state[0]) === "REACTION" || stripBrackets(msg.data.coin.state[0]) === "REPLY_REACTION") {
    if (+msg.data.coin.amount < 0.0001) {
      logWithLevel("Message below 0.0001 reaction threshold.. ! " + msg.data.coin.amount, "error");
      return false;
    }
  } else if (+msg.data.coin.amount < 0.01) {
    logWithLevel("Message below 0.01 threshold.. ! " + msg.data.coin.amount, "error");
    return false;
  }
  return true;
}

function decodeHexString(hexStr, /* isHistorical, */ callback) {
  if (!hexStr) {
    callback("");
    return;
  }
  try {
    // Check if the string starts with '0x' to determine if it's hex encoded
    if (hexStr.startsWith("0x")) {
      // Use Minima's convert command to convert from HEX to String
      MDS.cmd(`convert from:HEX to:String data:${hexStr}`, function (resp) {
        if (resp.status) {
          const decodedString = decodeURIComponent(resp.response.conversion);
          callback(decodedString);
        } else {
          logWithLevel("ERROR: Convert command failed: " + JSON.stringify(resp), "error");
          callback("");
        }
      });
    } else {
      // If not hex encoded, return the original string
      callback(hexStr);
    }
  } catch (e) {
    logWithLevel("ERROR: Error decoding string: " + e, "error");
    callback("");
  }
}