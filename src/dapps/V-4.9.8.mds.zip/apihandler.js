/**
 * API Handler for MINIVOX transactions
 */

// Add this at the top of the file
function logWithLevel(msg, level) {
    if (typeof level === "undefined") level = "error";
    if (
        typeof MDS !== 'undefined' &&
        MDS.appLogging &&
        MDS.logLevels &&
        MDS.logLevels[level] !== undefined &&
        MDS.logLevels[level] >= MDS.logLevels[MDS.logLevel]
    ) {
        MDS.log(msg);
    }
}

// Note: SchemaConverter is loaded by service.js
logWithLevel("apihandler.js: Initializing API Handler", "info");
var ApiHandler = {
  handleRequest: function (msg) {
    try {
      const entry = JSON.parse(msg.data.message);

      if (entry.action === "NO_ACTION") {
        return;
      }

      // Log incoming request
      logWithLevel("apihandler.js: Parsed entry: " + JSON.stringify(entry, null, 2), "debug");

      if (!entry || !entry.entryType) {
        throw new Error("Invalid schema: missing entryType");
      }

      // Convert entry to legacy format based on type
      let legacyParams;
      logWithLevel(
        "apihandler.js: Converting to legacy format for type: " +
          entry.entryType,
        "debug"
      );

      switch (entry.entryType) {
        case "post":
        case "article":
        case "reply":
          logWithLevel("apihandler.js: Converting message to legacy format", "debug");
          legacyParams = SchemaConverter.convertMessageToLegacy(entry);
          logWithLevel(
            "apihandler.js: Legacy params for message: " +
              JSON.stringify(legacyParams, null, 2),
            "debug"
          );
          this.sendMessage(
            legacyParams,
            this.createCallback(msg, entry.entryType)
          );
          break;

        case "vote":
          logWithLevel("apihandler.js: Converting vote to legacy format", "debug");
          legacyParams = SchemaConverter.convertTipToLegacy(entry);
          logWithLevel(
            "apihandler.js: Legacy params for vote: " +
              JSON.stringify(legacyParams, null, 2),
            "debug"
          );
          this.sendTip(legacyParams, this.createCallback(msg, entry.entryType));
          break;

        case "payment":
          logWithLevel("apihandler.js: Converting payment to legacy format", "debug");
          legacyParams = SchemaConverter.convertPaymentToLegacy(entry);
          logWithLevel(
            "apihandler.js: Legacy params for payment: " +
              JSON.stringify(legacyParams, null, 2),
            "debug"
          );
          this.sendPayment(
            legacyParams,
            this.createCallback(msg, entry.entryType)
          );
          break;

        case "poll":
          logWithLevel("apihandler.js: Converting poll to legacy format", "debug");
          legacyParams = SchemaConverter.convertPollToLegacy(entry);
          logWithLevel(
            "apihandler.js: Legacy params for poll: " +
              JSON.stringify(legacyParams, null, 2),
            "debug"
          );
          this.sendPoll(
            legacyParams,
            this.createCallback(msg, entry.entryType)
          );
          break;

        case "poll_vote":
          logWithLevel("apihandler.js: Converting poll vote to legacy format", "debug");
          legacyParams = SchemaConverter.convertPollVoteToLegacy(entry);
          logWithLevel(
            "apihandler.js: Legacy params for poll vote: " +
              JSON.stringify(legacyParams, null, 2),
            "debug"
          );
          this.sendPollVote(
            legacyParams,
            this.createCallback(msg, entry.entryType)
          );
          break;

        case "read_message":
        case "read_tip":
        case "read_poll":
        case "read_poll_vote":
        case "read_payment":
          logWithLevel(
            "apihandler.js: Processing read operation for: " + entry.entryType,
            "debug"
          );
          this.readCoin(entry, this.createCallback(msg, entry.entryType));
          break;

        default:
          throw new Error("Unsupported entry type: " + entry.entryType);
      }
    } catch (error) {
      logWithLevel(
        "apihandler.js: Error processing request - " +
          (error.stack || error.message),
        "error"
      );
      MDS.api.reply(
        msg.data.from,
        msg.data.id,
        JSON.stringify({
          status: false,
          error: error.message,
        })
      );
    }
  },

  // Helper function to create response callback
  createCallback: function (msg, entryType) {
    return function (response) {
      logWithLevel("apihandler.js: Processing callback for type: " + entryType, "debug");
      logWithLevel(
        "apihandler.js: Raw response: " + JSON.stringify(response, null, 2),
        "debug"
      );

      // Extract the core type without the read_ prefix if it exists
      const coreType = entryType.replace("read_", "");
      logWithLevel("apihandler.js: Core type: " + coreType, "debug");

      // Check if the response is in error state
      if (!response) {
        logWithLevel("apihandler.js: Response in error state or empty", "error");
        // If the response includes data, we might still be able to convert it
        const errorData = response;
        logWithLevel(
          "apihandler.js: Error data: " + JSON.stringify(errorData, null, 2),
          "debug"
        );

        // For read operations, try to convert the data even if marked as error
        if (entryType.startsWith("read_") && errorData) {
          try {
            logWithLevel(
              "apihandler.js: Attempting to convert error data for read operation",
              "debug"
            );
            // Convert the data to schema format
            let schemaResponse = SchemaConverter.convertLegacyToNewSchema(
              errorData,
              coreType
            );
            logWithLevel(
              "apihandler.js: Converted error data: " +
                JSON.stringify(schemaResponse, null, 2),
              "debug"
            );

            if (schemaResponse) {
              logWithLevel(
                "apihandler.js: Successfully converted error data, sending response",
                "info"
              );
              MDS.api.reply(
                msg.data.from,
                msg.data.id,
                JSON.stringify({
                  status: true,
                  response: schemaResponse,
                })
              );
              return;
            }
          } catch (conversionError) {
            logWithLevel(
              "apihandler.js: Error converting error data: " + conversionError,
              "error"
            );
          }
        }

        // If conversion failed or it's not a read operation, send the error
        logWithLevel("apihandler.js: Sending error response", "error");
        MDS.api.reply(
          msg.data.from,
          msg.data.id,
          JSON.stringify({
            status: false,
            error: (response && response.error) || "Unknown error",
          })
        );
        return;
      }

      // For successful responses, convert to schema format
      try {
        logWithLevel(
          "apihandler.js: Converting successful response to schema format",
          "debug"
        );
        // Convert response to schema format
        const schemaResponse = SchemaConverter.convertLegacyToNewSchema(
          response,
          coreType
        );

        logWithLevel(
          "apihandler.js: Converted schema response: " +
            JSON.stringify(schemaResponse, null, 2),
          "debug"
        );

        MDS.api.reply(
          msg.data.from,
          msg.data.id,
          JSON.stringify({
            status: true,
            response: schemaResponse,
          })
        );
      } catch (error) {
        logWithLevel(
          "apihandler.js: Error converting successful response: " + error,
          "error"
        );
        MDS.api.reply(
          msg.data.from,
          msg.data.id,
          JSON.stringify({
            status: false,
            error: "Error converting response: " + error,
          })
        );
      }
    };
  },

  // Core functionality methods
  sendMessage: function (params, callback) {
    sendTxnMessage(
      params.category,
      params.title,
      params.message,
      params.user,
      params.pubkey,
      params.address,
      params.randId,
      params.created,
      params.description,
      callback
    );
  },

  sendTip: function (params, callback) {
    sendTxnTip(
      params.userPubkey,
      params.recipientAddr,
      params.recipientPubkey,
      params.randId,
      params.postId,
      params.amount,
      params.isAmp,
      params.isReply,
      callback
    );
  },

  sendPayment: function (params, callback) {
    sendPaymentTxn(
      params.recipientAddr,
      params.amount,
      params.description,
      params.isAnonymous,
      callback
    );
  },

  sendPoll: function (params, callback) {
    sendPollMessage(
      params.question,
      params.options,
      params.user,
      params.pubkey,
      params.address,
      params.randId,
      params.created,
      callback
    );
  },

  sendPollVote: function (params, callback) {
    sendPollVote(params.pollId, params.optionId, params.pubkey, callback);
  },

  readCoin: function (entry, callback) {
    const coin = entry.coin;
    if (!coin) {
      callback({ status: false, error: "Missing coin data" });
      return;
    }

    // Map read operations to appropriate functions
    switch (entry.entryType) {
      case "read_message":
        readMessageCoin(coin, callback);
        break;
      case "read_tip":
        readTipCoin(coin, callback);
        break;
      case "read_poll":
        readPollCoin(coin, callback);
        break;
      case "read_poll_vote":
        readPollVoteCoin(coin, callback);
        break;
      case "read_payment":
        readPaymentCoin(coin, callback);
        break;
      default:
        callback({ status: false, error: "Invalid read type" });
    }
  },
};
