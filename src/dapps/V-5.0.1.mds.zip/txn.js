// test constants - remove next 3 lines for prod 


// uncomment for prod version
const TEST_TXN_ADDRESS = "";
const TEST_TXN_TIP_ADDRESS = "";
const TXN_TEST_MODE = false;


const MINIVOX_TXN_ADDRESS = TXN_TEST_MODE
  ? TEST_TXN_ADDRESS
  : "0x6D696E69766F782061646472657373";
const MINIVOX_TXN_TIP_ADDRESS = TXN_TEST_MODE
  ? TEST_TXN_TIP_ADDRESS
  : "0x4D494E49564F585F414444524553";

function logWithLevel(msg, level) {
    if (typeof level === "undefined") level = "error";
    if (
        typeof MDS !== 'undefined' &&
        MDS.appLogging &&
        MDS.logLevels &&
        MDS.logLevels[level] !== undefined &&
        MDS.logLevels[level] >= MDS.logLevels[MDS.logLevel]
    ) {
        MDS.log(msg);
    }
}

function handleTransactionError(error) {
    // Check for specific "KeysDB LOCKED" error
    if (error && error.message && error.message.includes("KeysDB LOCKED")) {
        return "Please unlock your node or use V in READ mode.";
    }
    // Also check if the error is in the response object (from MDS.cmd)
    if (error && error.error && error.error.includes("KeysDB LOCKED")) {
        return "Please unlock your node or use V in READ mode.";
    }
    // Return the original error message for other errors
    return error.message || (error.error ? error.error : "Unknown error");
}

function getMessageHash(
  category,
  title,
  message,
  user,
  pubkey,
  address,
  randId,
  created,
  description
) {
  //Create one long string..
  var fullmessage =
    category +
    title +
    message +
    user +
    pubkey +
    address +
    randId +
    created +
    description +
    "";
  var urlencoded = encodeURIComponent(fullmessage);

  //Now hash it..
  return sha1(urlencoded);
}

function checkMessageSig(
  category,
  title,
  message,
  user,
  pubkey,
  address,
  randId,
  created,
  description,
  signature,
  callback
) {
  //First create the message signature..
  var hash = getMessageHash(
    category,
    title,
    message,
    user,
    pubkey,
    address,
    randId,
    created,
    description
  );

  //Now sign the hash..
  MDS.cmd(
    "maxverify data:" +
      hash +
      " publickey:" +
      pubkey +
      " signature:" +
      signature,
    function (ver) {
      if (ver.response.valid) {
        callback(true);
      } else {
        callback(false);
      }
    }
  );
}

function encodeString(str, callback) {
  if (!str) {
    callback("");
    logWithLevel("No string to encode");
    return;
  }
  // Use encodeURIComponent to properly encode emoji and other special characters
  str = encodeURIComponent(str);
  MDS.cmd(`convert from:String to:HEX data:"${str}"`, function (resp) {
    if (resp.status) {
      callback(resp.response.conversion);
    } else {
      logWithLevel("Convert command failed: " + JSON.stringify(resp));
      callback("");
    }
  });
}

function sendTxnMessage(
  category,
  title,
  message,
  user,
  pubkey,
  address,
  randId,
  created,
  description,
  finalCallback
) {
  try {
    if (category === "REPOST") {
      title = "";
    }

    // Always fetch the user's current profile description instead of using the passed description
    // This prevents custom descriptions from being used in transactions
    getUser(pubkey, function(userResp) {
      let userDescription = "No description available.";
      if (userResp.rows && userResp.rows.length > 0) {
        userDescription = userResp.rows[0].DESCRIPTION ? decodeStringFromDB(userResp.rows[0].DESCRIPTION) : "No description available.";
      }

      //First create the message signature..
      var hash = getMessageHash(
        category,
        title,
        message,
        user,
        pubkey,
        address,
        randId,
        created,
        userDescription // Use the fetched user description instead of the passed description
      );

          //Now sign the hash..
      MDS.cmd("maxsign data:" + hash, function (resp) {
        var signature = resp.response.signature;

        // Encode all strings in sequence
        encodeString(title, function (encodedTitle) {
          encodeString(message, function (encodedMessage) {
            encodeString(user, function (encodedUser) {
              encodeString(userDescription, function (encodedDescription) {
                //Now construct..
                var state = {};
                state[0] = "[" + category + "]";
                state[1] = "[" + encodedTitle + "]";
                state[2] = "[" + encodedMessage + "]";
                state[3] = "[" + encodedUser + "]";
                state[4] = randId.toString();
                state[5] = pubkey.toString();
                state[6] = signature.toString();
                state[7] = "[" + address + "]";
                state[8] = created.toString();
                state[9] = "[" + encodedDescription + "]";

                var func =
                  "send storestate:true amount:0.01 address:" +
                  MINIVOX_TXN_ADDRESS +
                  " state:" +
                  JSON.stringify(state);

                //run it..
                MDS.cmd(func, function (sendresp) {
                  if (finalCallback) {
                    // Check if the response contains an error
                    if (sendresp && !sendresp.status && sendresp.error) {
                      finalCallback({ status: false, error: handleTransactionError(sendresp) });
                    } else {
                      finalCallback(sendresp);
                    }
                  }
                });
              });
            });
          });
        });
      });
    });
  } catch (error) {
    logWithLevel("Error in sendTxnMessage: " + error, "error");
    if (finalCallback) {
      finalCallback({ status: false, error: handleTransactionError(error) });
    }
  }
}

// TIPS
function getTipHash(
  userPubkey,
  recipientAddr,
  recipientPubkey,
  randId,
  postId,
  amount,
  isAmp,
  isReply
) {
  // Normalize amount to remove trailing zeros and ensure consistent string representation
  const normalizedAmount = parseFloat(amount).toString();

  // For poll votes, use empty recipient address
  const effectiveRecipientAddr = postId.startsWith("POLL_")
    ? ""
    : recipientAddr;

  const tipdata = [
    userPubkey,
    effectiveRecipientAddr,
    recipientPubkey,
    randId,
    postId,
    normalizedAmount, // Use normalized amount
    isAmp,
    isReply,
  ].join("|");

  const urlencoded = encodeURIComponent(tipdata);
  return sha1(urlencoded);
}

function checkTipSig(
  userPubkey,
  recipientAddr,
  recipientPubkey,
  randId,
  postId,
  amount,
  isAmp,
  isReply,
  signature,
  callback
) {
  //First create the tip signature..
  var hash = getTipHash(
    userPubkey,
    recipientAddr,
    recipientPubkey,
    randId,
    postId,
    amount,
    isAmp,
    isReply
  );

  //Now verify the signature..
  MDS.cmd(
    "maxverify data:" +
      hash +
      " publickey:" +
      userPubkey +
      " signature:" +
      signature,
    function (ver) {
      if (ver.response.valid) {
        callback(true);
      } else {
        callback(false);
      }
    }
  );
}

function sendTxnTip(
  userPubkey,
  recipientAddr,
  recipientPubkey,
  randId,
  postId,
  amount,
  isAmp,
  isReply,
  callback
) {
  //First create the tip signature..
  var hash = getTipHash(
    userPubkey,
    recipientAddr,
    recipientPubkey,
    randId,
    postId,
    amount,
    isAmp,
    isReply
  );

  //Now sign the hash..
  MDS.cmd("maxsign data:" + hash, function (resp) {
    var signature = resp.response.signature;

    //Now construct..
    var state = {};
    state[0] = userPubkey.toString();
    state[1] = "[" + recipientAddr + "]";
    state[2] = "[" + recipientPubkey + "]";
    state[3] = randId.toString();
    state[4] = "[" + postId + "]";
    state[5] = amount.toString();
    state[6] = signature.toString();
    state[7] = isAmp.toString();
    state[8] = isReply.toString();

    const tip = isAmp
      ? Math.round((amount / 2 + Number.EPSILON) * 100) / 100
      : amount;
    //const tip = isAmp ? Math.round(amount/2) : 1;

    const func = isAmp
      ? `send multi:["${recipientAddr}:${tip}","${MINIVOX_TXN_TIP_ADDRESS}:${
          amount !== tip ? amount - tip : tip
        }"] state:${JSON.stringify(state)}`
      : `send storestate:true amount:${tip} address:${MINIVOX_TXN_TIP_ADDRESS} state:${JSON.stringify(
          state
        )}`;

    //run it..
    MDS.cmd(func, function (sendresp) {
      if (callback) {
        // Check if the response contains an error
        if (sendresp && !sendresp.status && sendresp.error) {
          callback({ status: false, error: handleTransactionError(sendresp) });
        } else {
          callback(sendresp);
        }
      } else {
        logWithLevel("Error sending tip: " + JSON.stringify(sendresp), "error");
      }
    });
  });
}

// Add these functions alongside existing ones

function getPollHash(userPubkey, question, options, randId, created) {
  // Create one long string combining all options
  const optionsString = options.join("|");
  const fullMessage = userPubkey + question + optionsString + randId + created;
  const urlencoded = encodeURIComponent(fullMessage);

  return sha1(urlencoded);
}

function getPollVoteHash(userPubkey, pollId, optionId, randId) {
  const voteData = [userPubkey, pollId, optionId, randId].join("|");
  const urlencoded = encodeURIComponent(voteData);

  return sha1(urlencoded);
}

function sendPollMessage(
  question,
  options,
  user,
  pubkey,
  address,
  randId,
  created,
  finalCallback
) {
  try {
    // Create the poll message signature
    const hash = getPollHash(pubkey, question, options, randId, created);

    // Sign the hash
    MDS.cmd("maxsign data:" + hash, function (resp) {
      const signature = resp.response.signature;

      // Create the poll data object
      const pollData = {
        question: question,
        options: options,
      };

      // Encode the poll data as message
      encodeString(JSON.stringify(pollData), function (encodedMessage) {
        encodeString(user, function (encodedUser) {
          // Construct transaction state
          const state = {};
          state[0] = "[POLL]"; // category
          state[1] = "[]"; // title (empty for polls)
          state[2] = "[" + encodedMessage + "]"; // encoded poll data
          state[3] = "[" + encodedUser + "]"; // username
          state[4] = randId.toString(); // random ID
          state[5] = pubkey.toString(); // public key
          state[6] = signature.toString(); // signature
          state[7] = "[" + address + "]"; // address
          state[8] = created.toString(); // creation timestamp
          state[9] = "[]"; // description (empty for polls)

          const func =
            "send storestate:true amount:0.01 address:" +
            MINIVOX_TXN_ADDRESS +
            " state:" +
            JSON.stringify(state);

          // Execute the transaction
          MDS.cmd(func, function (sendresp) {
            if (finalCallback) {
              // Check if the response contains an error
              if (sendresp && !sendresp.status && sendresp.error) {
                finalCallback({ status: false, error: handleTransactionError(sendresp) });
              } else {
                finalCallback(sendresp);
              }
            } else {
              logWithLevel("Error sending poll: " + JSON.stringify(sendresp), "error");
            }
          });
        });
      });
    });
  } catch (error) {
    logWithLevel("Error in sendPollMessage: " + error, "error");
    if (finalCallback) {
      finalCallback({ status: false, error: handleTransactionError(error) });
    }
  }
}

function sendPollVote(pollId, optionId, pubkey, callback) {
  try {
    const randId = Math.floor(Math.random() * 1000000000);
    const hash = getPollVoteHash(pubkey, pollId, optionId, randId);

    // Sign the hash
    MDS.cmd("maxsign data:" + hash, function (resp) {
      const signature = resp.response.signature;

      // Construct transaction state
      const state = {};
      state[0] = pubkey.toString();
      state[1] = "[]"; // recipient address (empty for poll votes)
      state[2] = "[]"; // recipient pubkey (empty for poll votes)
      state[3] = randId.toString();
      state[4] = "[" + pollId + "]";
      state[5] = "[" + optionId + "]";
      state[6] = signature.toString();
      state[7] = "false"; // isAmp
      state[8] = "[POLL]"; // identifier for poll vote

      const func =
        "send storestate:true amount:0.01 address:" +
        MINIVOX_TXN_TIP_ADDRESS +
        " state:" +
        JSON.stringify(state);

      // Execute the transaction
      MDS.cmd(func, function (sendresp) {
        if (callback) {
          // Check if the response contains an error
          if (sendresp && !sendresp.status && sendresp.error) {
            callback({ status: false, error: handleTransactionError(sendresp) });
          } else {
            callback(sendresp);
          }
        } else {
          logWithLevel("Error sending poll vote: " + JSON.stringify(sendresp), "error");
        }
      });
    });
  } catch (error) {
    if (callback) {
      callback({ status: false, error: handleTransactionError(error) });
    }
  }
}

function checkPollMessageSig(
  userPubkey,
  question,
  options,
  randId,
  created,
  signature,
  callback
) {
  // Create the poll message signature
  const hash = getPollHash(userPubkey, question, options, randId, created);

  // Verify the signature
  MDS.cmd(
    "maxverify data:" +
      hash +
      " publickey:" +
      userPubkey +
      " signature:" +
      signature,
    function (ver) {
      callback(ver.response.valid);
    }
  );
}

function checkPollVoteSig(
  userPubkey,
  pollId,
  optionId,
  randId,
  signature,
  callback
) {
  // Create the vote signature
  const hash = getPollVoteHash(userPubkey, pollId, optionId, randId);

  // Verify the signature
  MDS.cmd(
    "maxverify data:" +
      hash +
      " publickey:" +
      userPubkey +
      " signature:" +
      signature,
    function (ver) {
      callback(ver.response.valid);
    }
  );
}

function getReactionHash(userPubkey, postId, emoji, randId) {
  const reactionData = [userPubkey, postId, emoji, randId].join("|");
  const urlencoded = encodeURIComponent(reactionData);
  return sha1(urlencoded);
}

function sendReactionTxn(postId, emoji, isReply, callback) {
  try {
    const randId = Math.floor(Math.random() * 1000000000);
    const hash = getReactionHash(USER_PUBKEY, postId, emoji, randId);

    // Sign the hash
    MDS.cmd("maxsign data:" + hash, function (resp) {
      const signature = resp.response.signature;

      // Construct transaction state
      const state = {};
      state[0] = "[" + (isReply ? "REPLY_REACTION" : "REACTION") + "]"; // Category first like other messages
      state[1] = "[]"; // No title
      state[2] = "[" + emoji + "]"; // Emoji as message
      state[3] = "[" + USER_PUBKEY + "]"; // User pubkey
      state[4] = randId.toString();
      state[5] = USER_PUBKEY.toString();
      state[6] = signature.toString();
      state[7] = "[" + postId + "]"; // Post ID being reacted to
      state[8] = Date.now().toString();
      state[9] = "[]"; // No description

      const func =
        "send storestate:true amount:0.0001 address:" +
        MINIVOX_TXN_ADDRESS + // Use message address instead of tip
        " state:" +
        JSON.stringify(state);

      // Execute the transaction
      MDS.cmd(func, function (sendresp) {
        if (callback) {
          // Check if the response contains an error
          if (sendresp && !sendresp.status && sendresp.error) {
            callback({ status: false, error: handleTransactionError(sendresp) });
          } else {
            callback(sendresp);
          }
        }
      });
    });
  } catch (error) {
    if (callback) {
      callback({ status: false, error: handleTransactionError(error) });
    }
  }
}

function checkReactionSig(
  userPubkey,
  postId,
  emoji,
  randId,
  signature,
  callback
) {
  const hash = getReactionHash(userPubkey, postId, emoji, randId);

  MDS.cmd(
    "maxverify data:" +
      hash +
      " publickey:" +
      userPubkey +
      " signature:" +
      signature,
    function (ver) {
      callback(ver.response.valid);
    }
  );
}

function sendPaymentTxn(recipientAddr, amount, description, isAnonymous, callback) {
  try {
    // Encode strings
    encodeString(isAnonymous ? "" : USER_NAME, function(encodedName) {
      encodeString(description || "", function(encodedDesc) {
        // Simple state with just 3 variables
        const state = {
          "0": "[PAYMENT]",
          "1": "[" + encodedName + "]",
          "2": "[" + encodedDesc + "]",
          "3": "[" + recipientAddr + "]",
          "4": "[" + amount + "]"
        };

        // Create multi-send transaction with tiny fee to MINIVOX_TXN_TIP_ADDRESS
        const func = `send mine:true multi:["${recipientAddr}:${amount}","${MINIVOX_TXN_TIP_ADDRESS}:0.00001"] state:${JSON.stringify(state)}`;

        // Execute the transaction
        MDS.cmd(func, function (sendresp) {
          if (callback) {
            // Check if the response contains an error
            if (sendresp && !sendresp.status && sendresp.error) {
              callback({ status: false, error: handleTransactionError(sendresp) });
            } else {
              callback(sendresp);
            }
          }
        });
      });
    });
  } catch (error) {
    if (callback) {
      callback({ status: false, error: handleTransactionError(error) });
    }
  }
}
