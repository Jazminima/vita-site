function sqlQuery(query, params, callback) {
  const placeholders = query.match(/\?/g) || [];
  if (placeholders.length !== params.length) {
    throw new Error(
      "Number of parameters doesn't match number of placeholders"
    );
  }

  let index = 0;
  const parameterizedQuery = query.replace(/\?/g, () => {
    const param = params[index++];
    if (typeof param === "string") {
      return "'" + param.replace(/'/g, "''") + "'";
    }
    return param;
  });

  MDS.sql(parameterizedQuery, callback);
}

function wipeDB(callback) {
  // First, disable foreign key constraints
  MDS.sql("SET REFERENTIAL_INTEGRITY FALSE", function () {
    logWithLevel("Disabled foreign key checks", "debug");

    // Drop all indexes first
    MDS.sql(
      "SELECT INDEX_NAME FROM INFORMATION_SCHEMA.INDEXES WHERE TABLE_SCHEMA = SCHEMA()",
      function (indexResult) {
        let indexes = indexResult.rows;
        let completedIndexDrops = 0;

        if (!indexes || indexes.length === 0) {
          logWithLevel("No indexes found to drop", "debug");
          dropTables();
          return;
        }

        // Drop each index
        indexes.forEach((index) => {
          if (index.INDEX_NAME !== 'PRIMARY_KEY') { // Skip primary key indexes
            const dropIndexSQL = `DROP INDEX IF EXISTS ${index.INDEX_NAME}`;
            MDS.sql(dropIndexSQL, function (msg) {
              logWithLevel(`Attempting to drop index ${index.INDEX_NAME}`, "debug");
              completedIndexDrops++;
              if (completedIndexDrops === indexes.length) {
                dropTables();
              }
            });
          } else {
            completedIndexDrops++;
            if (completedIndexDrops === indexes.length) {
              dropTables();
            }
          }
        });
      }
    );

    function dropTables() {
      // Get all tables
      MDS.sql(
        "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = SCHEMA()",
        function (result) {
          let tables = result.rows;
          let completedDrops = 0;

          logWithLevel("Found tables: " + JSON.stringify(tables), "debug");

          if (!tables || tables.length === 0) {
            logWithLevel("No tables found to drop", "debug");
            finishWipe();
            return;
          }

          // Drop each table
          tables.forEach((table) => {
            const dropSQL = `DROP TABLE IF EXISTS ${table.TABLE_NAME} CASCADE`;
            MDS.sql(dropSQL, function (msg) {
              if (msg.status) {
                logWithLevel(`Successfully dropped table ${table.TABLE_NAME}`, "debug");
              } else {
                logWithLevel(`Error dropping table ${table.TABLE_NAME}: ${msg}`, "error");
              }

              completedDrops++;
              if (completedDrops === tables.length) {
                finishWipe();
              }
            });
          });
        }
      );
    }

    function finishWipe() {
      // Re-enable foreign key constraints
      MDS.sql("SET REFERENTIAL_INTEGRITY TRUE", function () {
        logWithLevel("Re-enabled foreign key checks", "debug");
        if (callback) {
          callback();
        }
      });
    }
  });
}

function encodeStringForDB(str) {
  if (!str) return "";
  // Check if the string is already JSON
  try {
    JSON.parse(str);
    return str; // It's already JSON, return as is
  } catch (e) {
    // It's not JSON, so stringify it
    return JSON.stringify(str);
  }
}

function decodeStringFromDB(str) {
  if (!str) return "";
  try {
    // First, try to parse it as JSON
    return JSON.parse(str);
  } catch (e) {
    // If parsing fails, it's probably an old-format string
    // Try to decode it as a URI component (old format)
    try {
      return decodeURIComponent(str);
    } catch (e2) {
      // If both methods fail, return the original string
      logWithLevel("Failed to decode string: " + str, "warn");
      return str;
    }
  }
}

function createDB(callback) {
  const postsSQL = `CREATE TABLE IF NOT EXISTS vox_posts (
        user_name varchar(128) NOT NULL,
        user_address varchar(128),
        user_pubkey varchar(1024) NOT NULL,
        title varchar(128),
        message varchar(16384) NOT NULL,
        post_id varchar(128) PRIMARY KEY,
        is_read tinyint(1) NOT NULL DEFAULT 0,
        total_tips bigint NOT NULL DEFAULT 0,
        reply_count INT DEFAULT 0,
        created bigint NOT NULL,
        last_reply_time bigint DEFAULT NULL,
        category VARCHAR(10) NOT NULL DEFAULT 'POST',
        is_voted BOOLEAN DEFAULT FALSE,
        reactions VARCHAR(4096) DEFAULT '{"👍":[],"❤️":[],"😂":[],"😮":[],"🔥":[],"🚀":[],"😢":[],"🤮":[]}',
        subv VARCHAR(32)
  )`;

  MDS.sql(postsSQL, function (msg) {
    const userProfilesSQL = `CREATE TABLE IF NOT EXISTS user_profiles (
        user_pubkey varchar(1024) PRIMARY KEY,
        user_name varchar(128) NOT NULL,
        user_address varchar(128),
        created bigint NOT NULL,
        last_active bigint NOT NULL,
        is_blocked tinyint(1) NOT NULL DEFAULT 0,
        is_subscribed tinyint(1) NOT NULL DEFAULT 0,
        description varchar(500) DEFAULT NULL
      )`;

    MDS.sql(userProfilesSQL, function (msg) {
      const userPrefsSQL = `CREATE TABLE IF NOT EXISTS user_preferences (
          user_pubkey varchar(1024) PRIMARY KEY,
          default_tip_amt decimal(10,2) NOT NULL DEFAULT 0.1,
          confirmation_required tinyint(1) NOT NULL DEFAULT 0,
          total_received_payments decimal(10,2) NOT NULL DEFAULT 0,
          notify_on_post tinyint(1) NOT NULL DEFAULT 1,
          notify_on_reply tinyint(1) NOT NULL DEFAULT 1,
          notify_on_upvote tinyint(1) NOT NULL DEFAULT 1,
          notify_on_repost tinyint(1) NOT NULL DEFAULT 1,
          notify_on_payment tinyint(1) NOT NULL DEFAULT 1
      )`;

      MDS.sql(userPrefsSQL, function (msg) {
        const repliesSQL = `CREATE TABLE IF NOT EXISTS replies (
          user_name VARCHAR(128) NOT NULL,
          user_address VARCHAR(128),
          user_pubkey VARCHAR(1024) NOT NULL,
          reply_id VARCHAR(128) PRIMARY KEY,
          parent_post_id VARCHAR(128) NOT NULL,
          message VARCHAR(4096) NOT NULL,
          created BIGINT NOT NULL,
          total_tips bigint NOT NULL DEFAULT 0,
          reactions VARCHAR(4096) DEFAULT '{"👍":[],"❤️":[],"😂":[],"😮":[],"🔥":[],"🚀":[],"😢":[],"🤮":[]}',
          FOREIGN KEY (parent_post_id) REFERENCES vox_posts(post_id)
        )`;

        MDS.sql(repliesSQL, function (msg) {
          const pollOptionsSQL = `CREATE TABLE IF NOT EXISTS poll_options (
            option_id VARCHAR(128) PRIMARY KEY,
            poll_id VARCHAR(128) NOT NULL,
            option_text VARCHAR(256) NOT NULL,
            vote_count INT DEFAULT 0,
            FOREIGN KEY (poll_id) REFERENCES vox_posts(post_id) ON DELETE CASCADE
          )`;

          MDS.sql(pollOptionsSQL, function (msg) {
            const notificationsSQL = `CREATE TABLE IF NOT EXISTS notifications (
              id VARCHAR(128) PRIMARY KEY,
              user_pubkey VARCHAR(1024) NOT NULL,
              type VARCHAR(20) NOT NULL,
              message VARCHAR(512) NOT NULL,
              related_id VARCHAR(128),
              created BIGINT NOT NULL,
              is_read BOOLEAN DEFAULT FALSE,
              FOREIGN KEY (user_pubkey) REFERENCES user_profiles(user_pubkey)
            )`;

            MDS.sql(notificationsSQL, function (msg) {
              const processedTransactionsSQL = `CREATE TABLE IF NOT EXISTS processed_transactions (
                coin_id VARCHAR(128) PRIMARY KEY,
                transaction_type VARCHAR(20) NOT NULL,
                processed_at BIGINT NOT NULL,
                recipient_address VARCHAR(128) NOT NULL,
                amount DECIMAL(10,2) DEFAULT 0,
                related_id VARCHAR(128)
              )`;

              MDS.sql(processedTransactionsSQL, function (msg) {
              // Create index for trending subvs
              const trendingIndexSQL = `CREATE INDEX IF NOT EXISTS idx_posts_subv ON vox_posts(subv, created)`;
              
              // Create index for notifications
              const notificationsIndexSQL = `CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_pubkey, created)`;
                
                // Create indexes for processed transactions
                const processedTransactionsTypeAddressIndexSQL = `CREATE INDEX IF NOT EXISTS idx_processed_transactions_type_address ON processed_transactions(transaction_type, recipient_address)`;
                const processedTransactionsTimestampIndexSQL = `CREATE INDEX IF NOT EXISTS idx_processed_transactions_timestamp ON processed_transactions(processed_at)`;
              
              MDS.sql(trendingIndexSQL, function (msg) {
                MDS.sql(notificationsIndexSQL, function (msg) {
                    MDS.sql(processedTransactionsTypeAddressIndexSQL, function (msg) {
                      MDS.sql(processedTransactionsTimestampIndexSQL, function (msg) {
                  if (callback) {
                    callback(msg);
                  }
                      });
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
  });
}

function getPostByPostId(postId, callback) {
  const sql = `SELECT vp.*, up.user_name 
               FROM vox_posts vp
               INNER JOIN user_profiles up ON vp.user_pubkey = up.user_pubkey
               WHERE vp.post_id = ?`;

  sqlQuery(sql, [postId], function (sqlResp) {
    if (sqlResp.count > 0) {
      sqlResp.rows[0].user_name = decodeStringFromDB(sqlResp.rows[0].user_name);
      sqlResp.rows[0].message = decodeStringFromDB(sqlResp.rows[0].message);
      // ... decode other fields as necessary
      getRepliesByPostId(postId, function (repliesResp) {
        sqlResp.rows[0].replies = repliesResp.rows;
        callback(sqlResp);
      });
    } else {
      callback(sqlResp);
    }
  });
}

function checkPostExists(postId, callback) {
  getPostByPostId(postId, function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function getPostsByUserPubkey(userPubkey, callback) {
  var sql = `SELECT vp.*, up.user_name, 
               (SELECT COUNT(*) FROM replies WHERE parent_post_id = vp.post_id) AS reply_count
               FROM vox_posts vp
               INNER JOIN user_profiles up ON vp.user_pubkey = up.user_pubkey
               WHERE vp.user_pubkey = ?
               ORDER BY vp.created DESC`;

  sqlQuery(sql, [userPubkey], function (sqlResp) {
    callback(sqlResp);
  });
}

function getAllPosts(callback) {
  const sql = `
    SELECT p.*, up.user_name
    FROM vox_posts p
    LEFT JOIN user_profiles up ON p.user_pubkey = up.user_pubkey
    WHERE up.is_blocked = 0 OR up.is_blocked IS NULL
    ORDER BY p.created DESC`;

  MDS.sql(sql, function (sqlResp) {
    if (sqlResp.status) {
      const results = sqlResp.rows;
      let processedCount = 0;

      if (results.length === 0) {
        callback(sqlResp);
        return;
      }

      results.forEach((row, index) => {
        if (row.CATEGORY === "POLL") {
          // Fetch poll options
          const optionsSql = `SELECT * FROM poll_options WHERE poll_id = ?`;

          sqlQuery(optionsSql, [row.POST_ID], function (optionsResp) {
            if (optionsResp.status) {
              results[index].OPTIONS = optionsResp.rows;

              // Create a structured message for the poll
              const pollData = {
                question: row.MESSAGE, // MESSAGE contains the poll question
                options: optionsResp.rows,
              };
              results[index].MESSAGE = JSON.stringify(pollData);
            }

            processedCount++;
            if (processedCount === results.length) {
              callback({
                status: true,
                rows: results,
                count: results.length,
              });
            }
          });
        } else {
          processedCount++;
          if (processedCount === results.length) {
            callback({
              status: true,
              rows: results,
              count: results.length,
            });
          }
        }
      });
    } else {
      callback(sqlResp);
    }
  });
}

function getAllPostsBySubscribedUsers(callback) {
  var sql = `SELECT vp.*, up.user_name, 
               (SELECT COUNT(*) FROM replies WHERE parent_post_id = vp.post_id) AS reply_count
               FROM vox_posts vp
               INNER JOIN user_profiles up ON vp.user_pubkey = up.user_pubkey
               WHERE up.is_subscribed = 1
               ORDER BY vp.created DESC`;

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function insertPostUpdateUser(
  postId,
  userName,
  userPubkey,
  userAddress,
  message,
  isRead,
  created,
  description,
  subv,
  callback
) {
  checkPostExists(postId, function (exists) {
    if (exists) {
      if (callback) {
        callback(false);
      }
      return;
    }

    const enc_user = encodeStringForDB(userName);
    const enc_msg = encodeStringForDB(message);

    const sql = `INSERT INTO vox_posts(
      user_name, 
      user_address, 
      user_pubkey, 
      message, 
      post_id, 
      is_read, 
      total_tips, 
      created,
      subv
    ) VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?)`;

    sqlQuery(
      sql,
      [enc_user, userAddress, userPubkey, enc_msg, postId, isRead, created, subv],
      function (sqlResp) {
        if (sqlResp.status) {
          logWithLevel("Post inserted.", "info");
          checkUserExists(userPubkey, function (exists) {
            if (!exists) {
              addNewUser(
                userPubkey,
                userName,
                userAddress,
                created,
                0,
                0,
                description,
                function (sqlResp) {
                  if (sqlResp.status) {
                    callback(true);
                  } else {
                    logWithLevel("Error adding new user.", "error");
                    callback(false);
                  }
                }
              );
            } else {
              updateUserProfile(
                userPubkey,
                userName,
                userAddress,
                created,
                description,
                function (updateResp) {
                  if (updateResp.status) {
                    callback(true);
                  } else {
                    logWithLevel("Error updating user profile: " + userPubkey, "error");
                    callback(false);
                  }
                }
              );
            }
          });
        } else {
          logWithLevel("Error adding post: " + JSON.stringify(sqlResp), "error");
          callback(false);
        }
      }
    );
  });
}

function getUser(userPubkey, callback) {
  const sql = `SELECT * FROM user_profiles WHERE user_pubkey = ?`;

  sqlQuery(sql, [userPubkey], function (sqlResp) {
    if (sqlResp.rows && sqlResp.rows.length > 0) {
      const user = sqlResp.rows[0];
      user.DESCRIPTION = user.DESCRIPTION
        ? decodeStringFromDB(user.DESCRIPTION)
        : "";
    }
    callback(sqlResp);
  });
}

function checkUserExists(userPubkey, callback) {
  getUser(userPubkey, function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function addNewUser(
  userPubkey,
  userName,
  userAddress,
  created,
  isBlocked,
  isSubscribed,
  description,
  callback
) {
  const enc_user = encodeStringForDB(userName);
  const enc_description = description ? encodeStringForDB(description) : null;

  const sql = `INSERT INTO user_profiles(user_pubkey, user_name, user_address, created, last_active, is_blocked, is_subscribed, description)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

  sqlQuery(
    sql,
    [
      userPubkey,
      enc_user,
      userAddress,
      created,
      created,
      isBlocked,
      isSubscribed,
      enc_description,
    ],
    function (sqlResp) {
      callback(sqlResp);
    }
  );
}

function checkUserBlocked(userPubkey, callback) {
  const sql = `SELECT * FROM user_profiles WHERE user_pubkey = ? AND is_blocked = 1`;

  sqlQuery(sql, [userPubkey], function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function deleteUserMessages(userPubKey, callback) {
  const sql = `DELETE FROM vox_posts WHERE user_pubkey = ?`;

  sqlQuery(sql, [userPubKey], function (sqlResp) {
    callback(true);
  });
}

function blockUser(userPubkey, callback) {
  checkUserBlocked(userPubkey, function (isBlocked) {
    if (isBlocked) {
      logWithLevel("User already blocked: " + userPubkey, "info");
      callback(true);
    } else {
      const sql = `UPDATE user_profiles SET is_blocked = 1
                         WHERE user_pubkey = ?`;

      sqlQuery(sql, [userPubkey], function (sqlResp) {
        deleteUserMessages(userPubkey, function (deleted) {
          if (!deleted) {
            logWithLevel("Deletion failed for user: " + userPubkey, "error");
            callback(false);
          }
          callback(true);
        });
      });
    }
  });
}

function unBlockUser(userPubkey, callback) {
  checkUserBlocked(userPubkey, function (isBlocked) {
    if (isBlocked) {
      const sql = `UPDATE user_profiles SET is_blocked = 0
                         WHERE user_pubkey = ?`;

      sqlQuery(sql, [userPubkey], function (sqlResp) {
        callback(true);
      });
    } else {
      logWithLevel("User already unblocked: " + userPubkey, "info");
      callback(true);
    }
  });
}

function getAllBlockedUsers(callback) {
  const sql = "SELECT * FROM user_profiles WHERE is_blocked = 1";

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function checkUserSubscribed(userPubkey, callback) {
  const sql = `SELECT * FROM user_profiles WHERE user_pubkey = ? AND is_subscribed = 1`;

  sqlQuery(sql, [userPubkey], function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function followUser(userPubkey, callback) {
  checkUserSubscribed(userPubkey, function (subscribed) {
    if (subscribed) {
      logWithLevel("Already subscribed to: " + userPubkey, "info");
      if (callback) {
        callback(false);
      }
    } else {
      const sql = `UPDATE user_profiles SET is_subscribed = 1
                         WHERE user_pubkey = ?`;

      sqlQuery(sql, [userPubkey], function (sqlResp) {
        if (callback) {
          callback(sqlResp);
        }
      });
    }
  });
}

function unFollowUser(userPubkey, callback) {
  checkUserSubscribed(userPubkey, function (subscribed) {
    if (!subscribed) {
      logWithLevel("Already not subscribed to: " + userPubkey, "info");
      if (callback) {
        callback(false);
      }
    } else {
      const sql = `UPDATE user_profiles SET is_subscribed = 0
                         WHERE user_pubkey = ?`;

      sqlQuery(sql, [userPubkey], function (sqlResp) {
        if (callback) {
          callback(sqlResp);
        }
      });
    }
  });
}

function getAllSubscribedUsers(callback) {
  const sql = "SELECT * FROM user_profiles WHERE is_subscribed = 1";

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function updatePostScore(postId, tipAmount, isAmp, callback) {
  const sql = `UPDATE vox_posts 
               SET total_tips = total_tips ${isAmp ? "+" : "-"} ?
               WHERE post_id = ?`;

  sqlQuery(sql, [tipAmount, postId], function (sqlResp) {
    if (callback) {
      callback(sqlResp);
    }
  });
}

function updateReplyScore(replyId, tipAmount, isAmp, callback) {
  const sql = `UPDATE replies 
               SET total_tips = total_tips + ?
               WHERE reply_id = ?`;

  sqlQuery(sql, [isAmp ? tipAmount : -tipAmount, replyId], function (sqlResp) {
    if (callback) {
      callback(sqlResp);
    }
  });
}

function getCurrentUserPreferences(callback) {
  const sql = "SELECT * FROM user_preferences LIMIT 1";

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function checkIfUserPrefExists(callback) {
  getCurrentUserPreferences(function (sqlResp) {
    callback(sqlResp.count > 0);
  });
}

function addUserPreferences(userPubkey, callback) {
  checkIfUserPrefExists(function (exists) {
    if (!exists) {
      const sql = `INSERT INTO user_preferences(user_pubkey) 
                         VALUES(?)`;

      sqlQuery(sql, [userPubkey], function (sqlResp) {
        if (callback) {
          callback(true);
        }
      });
    } else {
      if (callback) {
        callback(false);
      }
    }
  });
}

function updateUserProfile(
  userPubkey,
  userName,
  userAddress,
  lastActive,
  description,
  callback
) {
  const enc_user = encodeStringForDB(userName);
  const enc_description = description ? encodeStringForDB(description) : null;

  const updateUserSQL = `UPDATE user_profiles 
                         SET user_name = ?,
                             user_address = ?,
                             last_active = ?,
                             description = ?
                         WHERE user_pubkey = ?`;

  sqlQuery(
    updateUserSQL,
    [enc_user, userAddress, lastActive, enc_description, userPubkey],
    function (updateResp) {
      if (callback) {
        callback(updateResp);
      }
    }
  );
}

function updateUserPreferences(defaultTipMinima, isConfirmationReq, callback) {
  const sql = `UPDATE user_preferences 
                 SET default_tip_amt = ?, 
                     confirmation_required = ?`;

  sqlQuery(sql, [defaultTipMinima, isConfirmationReq], function (sqlResp) {
    if (callback) {
      callback(sqlResp);
    }
  });
}

function insertReplyUpdateUser(
  replyId,
  parentPostId,
  userPubkey,
  userName,
  userAddress,
  message,
  created,
  description,
  callback
) {
      // First check if parent post exists
    const checkPostSQL = `SELECT post_id FROM vox_posts WHERE post_id = ?`;

    sqlQuery(checkPostSQL, [parentPostId], function (checkResp) {
      if (!checkResp.status || checkResp.count === 0) {
        logWithLevel("Cannot insert reply - parent post not found.", "error");
        callback(false);
        return;
      }

      // Check if reply already exists
      checkReplyExists(replyId, function (replyExists) {
        if (replyExists) {
          logWithLevel("Reply already exists.", "warn");
          callback(false);
          return;
        }

      // Continue with reply insertion logic
      const encMessage = encodeStringForDB(message);
      const sql = `INSERT INTO replies (reply_id, parent_post_id, user_pubkey, user_name, user_address, message, created)
                   VALUES (?, ?, ?, ?, ?, ?, ?)`;

      sqlQuery(
        sql,
        [
          replyId,
          parentPostId,
          userPubkey,
          userName,
          userAddress,
          encMessage,
          created,
        ],
        function (sqlResp) {
          if (sqlResp.status) {
            logWithLevel("Reply inserted.", "info");
            // Update reply count and last_reply_time
            incrementReplyCount(parentPostId, function () {
              checkUserExists(userPubkey, function (exists) {
                if (!exists) {
                  addNewUser(
                    userPubkey,
                    userName,
                    userAddress,
                    created,
                    0,
                    0,
                    description,
                    function (sqlResp) {
                      if (sqlResp.status) {
                        callback(true);
                      } else {
                        logWithLevel("Failed to add new user.", "error");
                        callback(false);
                      }
                    }
                  );
                } else {
                  updateUserProfile(
                    userPubkey,
                    userName,
                    userAddress,
                    created,
                    description,
                    function (updateResp) {
                      if (updateResp.status) {
                        callback(true);
                      } else {
                        logWithLevel("Failed to update user profile.", "error");
                        callback(false);
                      }
                    }
                  );
                }
              });
            });
          } else {
            // Ensure we call the callback even when there's an error
            callback(false);
          }
        }
      );
    });
  });
}

function incrementReplyCount(postId, callback) {
  const sql = `UPDATE vox_posts 
                 SET reply_count = reply_count + 1,
                     last_reply_time = ?
                 WHERE post_id = ?`;

  const currentTime = Date.now();
  sqlQuery(sql, [currentTime, postId], function (sqlResp) {
    if (callback) {
      callback(sqlResp);
    }
  });
}

function getRepliesByPostId(postId, callback) {
  const sql = `
    SELECT r.*, up.user_name,
           (SELECT user_address FROM vox_posts WHERE user_pubkey = r.user_pubkey LIMIT 1) as user_address
    FROM replies r
    INNER JOIN user_profiles up ON r.user_pubkey = up.user_pubkey
    WHERE r.parent_post_id = ? 
    AND (up.is_blocked = 0 OR up.is_blocked IS NULL)
    ORDER BY r.created DESC
  `;

  sqlQuery(sql, [postId], function (sqlResp) {
    callback(sqlResp);
  });
}

function insertArticleUpdateUser(
  postId,
  userName,
  userPubkey,
  userAddress,
  title,
  message,
  isRead,
  created,
  description,
  subv,
  callback
) {
  checkPostExists(postId, function (exists) {
    if (exists) {
      if (callback) {
        callback(false);
      }
      return;
    }

    const enc_user = encodeStringForDB(userName);
    const enc_msg = encodeStringForDB(message);
    const enc_title = encodeStringForDB(title);

    const sql = `INSERT INTO vox_posts(
    user_name, 
    user_address, 
    user_pubkey, 
    title, 
    message, 
    post_id, 
    is_read, 
    total_tips, 
    created, 
    category, 
    subv
    ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, 'ARTICLE', ?)`;

    sqlQuery(
      sql,
      [
        enc_user,
        userAddress,
        userPubkey,
        enc_title,
        enc_msg,
        postId,
        isRead,
        created,
        subv,
      ],
      function (sqlResp) {
        if (sqlResp.status) {
          logWithLevel("Article inserted.", "info");
          checkUserExists(userPubkey, function (exists) {
            if (!exists) {
              addNewUser(
                userPubkey,
                userName,
                userAddress,
                created,
                0,
                0,
                description,
                function (sqlResp) {
                  if (sqlResp.status) {
                    callback(true);
                  } else {
                    logWithLevel("Failed to add new user.", "error");
                    callback(false);
                  }
                }
              );
            } else {
              updateUserProfile(
                userPubkey,
                userName,
                userAddress,
                created,
                description,
                function (updateResp) {
                  if (updateResp.status) {
                    callback(true);
                  } else {
                    logWithLevel("Failed to update user profile.", "error");
                    callback(false);
                  }
                }
              );
            }
          });
        }
      }
    );
  });
}

function getNotificationPreferences(userPubkey, callback) {
  const sql = `SELECT notify_on_post, notify_on_reply, notify_on_upvote, notify_on_repost, notify_on_payment
               FROM user_preferences 
               WHERE user_pubkey = ?`;

  sqlQuery(sql, [userPubkey], function (sqlResp) {
    if (sqlResp.count > 0) {
      // Convert database column names to expected JavaScript property names
      // Handle null/undefined values by defaulting to true
      callback({
        NOTIFY_ON_POST: Number(sqlResp.rows[0].notify_on_post) || 1,
        NOTIFY_ON_REPLY: Number(sqlResp.rows[0].notify_on_reply) || 1,
        NOTIFY_ON_UPVOTE: Number(sqlResp.rows[0].notify_on_upvote) || 1,
        NOTIFY_ON_REPOST: Number(sqlResp.rows[0].notify_on_repost) || 1,
        NOTIFY_ON_PAYMENT: Number(sqlResp.rows[0].notify_on_payment) || 1
      });
    } else {
      callback({
        NOTIFY_ON_POST: true,
        NOTIFY_ON_REPLY: true,
        NOTIFY_ON_UPVOTE: true,
        NOTIFY_ON_REPOST: true,
        NOTIFY_ON_PAYMENT: true
      });
    }
  });
}

function updateNotificationPreferences(userPubkey, preferences, callback) {
  const sql = `UPDATE user_preferences 
               SET notify_on_post = ?,
                   notify_on_reply = ?,
                   notify_on_upvote = ?,
                   notify_on_repost = ?,
                   notify_on_payment = ?
               WHERE user_pubkey = ?`;

  // Validate and convert values to prevent NaN
  const validatedPreferences = [
    Number(preferences.NOTIFY_ON_POST) || 0,
    Number(preferences.NOTIFY_ON_REPLY) || 0,
    Number(preferences.NOTIFY_ON_UPVOTE) || 0,
    Number(preferences.NOTIFY_ON_REPOST) || 0,
    Number(preferences.NOTIFY_ON_PAYMENT) || 0,
    userPubkey,
  ];

  sqlQuery(sql, validatedPreferences, callback);
}

function getTotalScoreByPubkey(userPubkey, callback) {
  const sql = `SELECT COALESCE(SUM(total_tips), 0) as total_score 
               FROM (
                 SELECT total_tips FROM vox_posts WHERE user_pubkey = ?
                 UNION ALL
                 SELECT total_tips FROM replies WHERE user_pubkey = ?
               )`;

  sqlQuery(sql, [userPubkey, userPubkey], function (sqlResp) {
    if (sqlResp.rows && sqlResp.rows.length > 0) {
      const totalScore = sqlResp.rows[0].TOTAL_SCORE || 0;
      callback(totalScore);
    } else {
      callback(0);
    }
  });
}

function votePoll(pollId, optionId, isCurrentUser, callback) {
  getPollWithOptions(pollId, function (pollData) {
    if (!pollData.status) {
      if (callback) callback({ status: false, error: "Poll not found" });
      return;
    }

    // Update option vote count
    const optionSql = `UPDATE poll_options 
                      SET vote_count = vote_count + 1 
                      WHERE option_id = ? AND poll_id = ?`;

    sqlQuery(optionSql, [optionId, pollId], function (optResp) {
      if (!optResp.status) {
        if (callback)
          callback({ status: false, error: "Failed to update option votes" });
        return;
      }

      // Update total votes and mark as voted only if it's the current user
      const postSql = `UPDATE vox_posts 
                      SET is_voted = CASE WHEN ? THEN TRUE ELSE is_voted END
                      WHERE post_id = ? AND category = 'POLL'`;

      sqlQuery(postSql, [isCurrentUser, pollId], function (pollResp) {
        if (callback) {
          callback(pollResp);
        }
      });
    });
  });
}

function getPollWithOptions(pollId, callback) {
  if (!pollId) {
    logWithLevel("Error: pollId is undefined or null", "error");
    callback({ status: false, error: "Invalid poll ID" });
    return;
  }

  const sql = `
    SELECT p.*, up.user_name 
    FROM vox_posts p
    INNER JOIN user_profiles up ON p.user_pubkey = up.user_pubkey
    WHERE p.post_id = ? AND p.category = 'POLL'`;

  sqlQuery(sql, [pollId], function (pollResp) {
    if (!pollResp.status || !pollResp.rows.length) {
      logWithLevel("Error or no poll found for ID: " + pollId, "error");
      callback({ status: false, error: "Poll not found" });
      return;
    }

    const optionsSql = `
      SELECT option_id, option_text, COALESCE(vote_count, 0) as vote_count
      FROM poll_options 
      WHERE poll_id = ?
      ORDER BY CAST(SUBSTRING(option_id, POSITION('_' IN option_id) + 1) AS INT)`;

    sqlQuery(optionsSql, [pollId], function (optionsResp) {
          if (!optionsResp.status) {
      logWithLevel("Error fetching options for poll: " + pollId, "error");
      callback({ status: false, error: "Failed to fetch poll options" });
      return;
    }

      callback({
        status: true,
        poll: pollResp.rows[0],
        options: optionsResp.rows,
      });
    });
  });
}

function getAllPolls(callback) {
  const sql = `SELECT p.*, up.user_name
               FROM polls p
               INNER JOIN user_profiles up ON p.user_pubkey = up.user_pubkey
               ORDER BY p.created DESC`;

  MDS.sql(sql, callback);
}

function insertPollUpdateUser(
  pollId,
  userName,
  userPubkey,
  userAddress,
  question,
  options,
  created,
  description,
  callback
) {
  checkPostExists(pollId, function (exists) {
    if (exists) {
      if (callback) {
        callback(false);
      }
      return;
    }

    const enc_user = encodeStringForDB(userName);
    const enc_question = encodeStringForDB(question);

    const postSQL = `INSERT INTO vox_posts (
      post_id, 
      user_pubkey, 
      user_name, 
      user_address, 
      message, 
      created, 
      category, 
      is_voted, 
      total_tips
    ) VALUES (?, ?, ?, ?, ?, ?, 'POLL', FALSE, 0)`;
    //pollId is the postId

    sqlQuery(
      postSQL,
      [pollId, userPubkey, enc_user, userAddress, enc_question, created],
      function (sqlResp) {
        if (!sqlResp.status) {
          logWithLevel("Failed to insert poll", "error");
          if (callback) callback(false);
          return;
        }

        let completedOptions = 0;
        options.forEach((optionText, index) => {
          const optionId = pollId + "_" + index;
          const optionSQL = `INSERT INTO poll_options (option_id, poll_id, option_text)
                         VALUES (?, ?, ?)`;

          sqlQuery(
            optionSQL,
            [optionId, pollId, optionText],
            function (optResp) {
              completedOptions++;

              if (completedOptions === options.length) {
                checkUserExists(userPubkey, function (exists) {
                  if (!exists) {
                    addNewUser(
                      userPubkey,
                      userName,
                      userAddress,
                      created,
                      0,
                      0,
                      description,
                      function (sqlResp) {
                        callback(sqlResp.status);
                      }
                    );
                  } else {
                    updateUserProfile(
                      userPubkey,
                      userName,
                      userAddress,
                      created,
                      description,
                      function (updateResp) {
                        callback(updateResp.status);
                      }
                    );
                  }
                });
              }
            }
          );
        });
      }
    );
  });
}

function insertRepostUpdateUser(
  postId,
  userName,
  userPubkey,
  userAddress,
  message,
  created,
  description,
  subv,
  callback
) {
  checkPostExists(postId, function (exists) {
    if (exists) {
      if (callback) {
        callback(false);
      }
      return;
    }

    const enc_user = encodeStringForDB(userName);
    const enc_msg = encodeStringForDB(
      typeof message === "string" ? message : JSON.stringify(message)
    );

    const sql = `INSERT INTO vox_posts(
      user_name, 
      user_address, 
      user_pubkey, 
      message, 
      post_id, 
      is_read, 
      total_tips, 
      created,
      category,
      subv
    ) VALUES (?, ?, ?, ?, ?, 1, 0, ?, 'REPOST', ?)`;

    sqlQuery(
      sql,
      [enc_user, userAddress, userPubkey, enc_msg, postId, created, subv],
      function (sqlResp) {
        if (sqlResp.status) {
          checkUserExists(userPubkey, function (exists) {
            if (!exists) {
              addNewUser(
                userPubkey,
                userName,
                userAddress,
                created,
                0,
                0,
                description,
                function (sqlResp) {
                  callback(sqlResp.status);
                }
              );
            } else {
              updateUserProfile(
                userPubkey,
                userName,
                userAddress,
                created,
                description,
                function (updateResp) {
                  callback(updateResp.status);
                }
              );
            }
          });
        } else {
          logWithLevel("Error adding repost: " + JSON.stringify(sqlResp), "error");
          callback(false);
        }
      }
    );
  });
}

function updateReactions(postId, userPubkey, emoji, callback) {
  // First get current reactions
  const getSQL = `SELECT reactions FROM vox_posts WHERE post_id = ?`;

  sqlQuery(getSQL, [postId], function (result) {
    if (!result.status) {
      logWithLevel("ERROR: Failed to get current reactions", "error");
      callback(false);
      return;
    }

    let currentReactions = {};
    try {
      currentReactions = JSON.parse(result.rows[0].REACTIONS);
    } catch (e) {
      currentReactions = { "👍": [], "❤️": [], "😂": [], "😮": [], "🔥": [], "🚀": [], "😢": [], "🤮": [] };
    }

    // Update the reactions
    if (!currentReactions[emoji]) {
      currentReactions[emoji] = [];
    }

    // Remove reaction if already exists (toggle behavior)
    const userIndex = currentReactions[emoji].indexOf(userPubkey);
    if (userIndex > -1) {
      currentReactions[emoji].splice(userIndex, 1);
    } else {
      currentReactions[emoji].push(userPubkey);
    }

    // Update in database
    const updateSQL = `UPDATE vox_posts 
                      SET reactions = ? 
                      WHERE post_id = ?`;

    sqlQuery(
      updateSQL,
      [JSON.stringify(currentReactions), postId],
      function (updateResult) {
        if (!updateResult.status) {
          logWithLevel("ERROR: Failed to record reaction", "error");
        }
        callback(updateResult.status);
      }
    );
  });
}

function getPostReactions(postId, callback) {
  const sql = `SELECT reactions FROM vox_posts WHERE post_id = ?`;
  
  sqlQuery(sql, [postId], function (result) {
    let reactions = { "👍": [], "❤️": [], "😂": [], "😮": [], "🔥": [], "🚀": [], "😢": [], "🤮": [] };

    if (result.status && result.rows.length > 0) {
      try {
        reactions = JSON.parse(result.rows[0].REACTIONS);
      } catch (e) {
        logWithLevel("Error parsing reactions: " + e, "error");
      }
    }

    callback(reactions);
  });
}

function getPostsBySubv(subv, callback) {
  const sql = `SELECT vp.*, up.user_name,
               (SELECT COUNT(*) FROM replies WHERE parent_post_id = vp.post_id) AS reply_count
               FROM vox_posts vp
               INNER JOIN user_profiles up ON vp.user_pubkey = up.user_pubkey
               WHERE vp.subv = ?
               ORDER BY vp.created DESC`;

  sqlQuery(sql, [subv], function (sqlResp) {
    callback(sqlResp);
  });
}

function updateReplyReactions(replyId, userPubkey, emoji, callback) {
  // Validate replyId before executing query
  if (!replyId) {
    logWithLevel("Warn: updateReplyReactions called with undefined/null replyId", "warn");
    callback(false);
    return;
  }
  
  // First get current reactions
  const getSQL = `SELECT reactions FROM replies WHERE reply_id = ?`;

  sqlQuery(getSQL, [replyId], function (result) {
    if (!result.status) {
      logWithLevel("ERROR: Failed to get current reply reactions", "error");
      callback(false);
      return;
    }

    let currentReactions = {};
    try {
      currentReactions = result.rows[0].REACTIONS ? JSON.parse(result.rows[0].REACTIONS) : 
        { "👍": [], "❤️": [], "😂": [], "😮": [], "🔥": [], "🚀": [], "😢": [], "🤮": [] };
    } catch (e) {
      currentReactions = { "👍": [], "❤️": [], "😂": [], "😮": [], "🔥": [], "🚀": [], "😢": [], "🤮": [] };
    }

    // Update the reactions
    if (!currentReactions[emoji]) {
      currentReactions[emoji] = [];
    }

    // Remove reaction if already exists (toggle behavior)
    const userIndex = currentReactions[emoji].indexOf(userPubkey);
    if (userIndex > -1) {
      currentReactions[emoji].splice(userIndex, 1);
    } else {
      currentReactions[emoji].push(userPubkey);
    }

    // Update in database
    const updateSQL = `UPDATE replies 
                      SET reactions = ? 
                      WHERE reply_id = ?`;

    sqlQuery(
      updateSQL,
      [JSON.stringify(currentReactions), replyId],
      function (updateResult) {
        if (!updateResult.status) {
          logWithLevel("ERROR: Failed to record reply reaction", "error");
        }
        callback(updateResult.status);
      }
    );
  });
}

function getReplyReactions(replyId, callback) {
  // Validate replyId before executing query
  if (!replyId) {
    logWithLevel("ERROR: getReplyReactions called with undefined/null replyId", "error");
    callback({ "👍": [], "❤️": [], "😂": [], "😮": [], "🔥": [], "🚀": [], "😢": [], "🤮": [] });
    return;
  }
  
  const sql = `SELECT reactions FROM replies WHERE reply_id = ?`;
  
  sqlQuery(sql, [replyId], function (result) {
    let reactions = { "👍": [], "❤️": [], "😂": [], "😮": [], "🔥": [], "🚀": [], "😢": [], "🤮": [] };

    if (result.status && result.rows.length > 0 && result.rows[0].REACTIONS) {
      try {
        reactions = JSON.parse(result.rows[0].REACTIONS);
      } catch (e) {
        logWithLevel("Error parsing reply reactions: " + e, "error");
      }
    }

    callback(reactions);
  });
}

// Add this comment to remind about creating the index
// NOTE: Run this once to improve performance:
// CREATE INDEX IF NOT EXISTS idx_posts_subv ON vox_posts(subv, created);

// Helper function to extract subv from message content
function extractSubvFromMessage(message) {
  const subvMatch = message.match(/v\/(\w+)/);
  return subvMatch ? subvMatch[1] : null;
}

function getTrendingSubvs(limit, timeWindowHours, callback) {
  // Set default values
  limit = limit || 5;
  timeWindowHours = timeWindowHours || 24;

  const timeWindowMs = timeWindowHours * 60 * 60 * 1000;
  const cutoffTime = Date.now() - timeWindowMs;



  // Get posts with subv tags
  const postsSql = `
    SELECT subv, created as activity_time FROM vox_posts 
    WHERE subv IS NOT NULL AND subv != '' AND created >= ?
  `;
  
  // Get replies to posts with subv tags
  const repliesToSubvPostsSql = `
    SELECT p.subv, r.created as activity_time
    FROM replies r
    INNER JOIN vox_posts p ON r.parent_post_id = p.post_id
    WHERE p.subv IS NOT NULL AND p.subv != '' AND r.created >= ?
  `;
  
  // Get all replies with v/ tags in their message
  const repliesWithSubvTagsSql = `
    SELECT r.message, r.created as activity_time
    FROM replies r
    WHERE r.message LIKE '%v/%' AND r.created >= ?
  `;

       // Get posts with subv tags
     sqlQuery(postsSql, [cutoffTime], function(postsResp) {
       if (!postsResp.status) {
         callback({ status: false, rows: [] });
         return;
       }
    
           // Get replies to posts with subv tags
       sqlQuery(repliesToSubvPostsSql, [cutoffTime], function(repliesToSubvResp) {
         if (!repliesToSubvResp.status) {
           callback({ status: false, rows: [] });
           return;
         }
      
               // Get replies with v/ tags in their message
         sqlQuery(repliesWithSubvTagsSql, [cutoffTime], function(repliesWithSubvResp) {
           if (!repliesWithSubvResp.status) {
             callback({ status: false, rows: [] });
             return;
           }
        
        // Process all the data
        const allActivities = [];
        
        // Add posts
        if (postsResp.rows) {
          postsResp.rows.forEach(row => {
            allActivities.push({
              subv: row.SUBV,
              activity_time: row.ACTIVITY_TIME
            });
          });
        }
        
        // Add replies to posts with subv tags
        if (repliesToSubvResp.rows) {
          repliesToSubvResp.rows.forEach(row => {
            allActivities.push({
              subv: row.SUBV,
              activity_time: row.ACTIVITY_TIME
            });
          });
        }
        
        // Process replies with subv tags in their message
        if (repliesWithSubvResp.rows) {
          repliesWithSubvResp.rows.forEach(row => {
            const extractedSubv = extractSubvFromMessage(row.MESSAGE);
            if (extractedSubv) {
              allActivities.push({
                subv: extractedSubv,
                activity_time: row.ACTIVITY_TIME
              });
            }
          });
        }
        
        // Group by subv and calculate counts and max times
        const subvStats = {};
        allActivities.forEach(activity => {
          if (!subvStats[activity.subv]) {
            subvStats[activity.subv] = {
              post_count: 0,
              last_post_time: 0
            };
          }
          subvStats[activity.subv].post_count++;
          if (activity.activity_time > subvStats[activity.subv].last_post_time) {
            subvStats[activity.subv].last_post_time = activity.activity_time;
          }
        });
        
        // Convert to array and sort by post count
        const results = Object.entries(subvStats)
          .map(([subv, stats]) => ({
            SUBV: subv,
            POST_COUNT: stats.post_count.toString(),
            LAST_POST_TIME: stats.last_post_time.toString()
          }))
          .sort((a, b) => parseInt(b.POST_COUNT) - parseInt(a.POST_COUNT))
          .slice(0, limit);
        
                 callback({ status: true, rows: results });
      });
    });
  });
}

function addNotification(userPubkey, type, message, relatedId, callback) {
  const id = Date.now().toString() + Math.random().toString(36).substring(7);
  const created = Date.now();

  const sql = `INSERT INTO notifications (id, user_pubkey, type, message, related_id, created)
               VALUES (?, ?, ?, ?, ?, ?)`;

  sqlQuery(sql, [id, userPubkey, type, message, relatedId, created], function(sqlResp) {
    if (callback) callback(sqlResp);
  });
}

function getNotifications(userPubkey, limit, offset, callback) {
  // Get notifications from the last 30 days
  const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
  
  const sql = `SELECT * FROM notifications 
               WHERE user_pubkey = ? 
               AND created > ?
               ORDER BY created DESC 
               LIMIT ? OFFSET ?`;

  sqlQuery(sql, [userPubkey, thirtyDaysAgo, limit, offset], function(sqlResp) {
    if (callback) callback(sqlResp);
  });
}

function getUnreadNotificationCount(userPubkey, callback) {
  const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
  
  const sql = `SELECT COUNT(*) as count 
               FROM notifications 
               WHERE user_pubkey = ? 
               AND is_read = FALSE 
               AND created > ?`;

  sqlQuery(sql, [userPubkey, thirtyDaysAgo], function(sqlResp) {
    if (callback) callback(sqlResp.rows[0].COUNT);
  });
}

function markNotificationAsRead(notificationId, callback) {
  const sql = `UPDATE notifications 
               SET is_read = TRUE 
               WHERE id = ?`;

  sqlQuery(sql, [notificationId], function(sqlResp) {
    if (callback) callback(sqlResp);
  });
}

function markAllNotificationsAsRead(userPubkey, callback) {
  const sql = `UPDATE notifications 
               SET is_read = TRUE 
               WHERE user_pubkey = ?`;

  sqlQuery(sql, [userPubkey], function(sqlResp) {
    if (callback) callback(sqlResp);
  });
}

function deleteOldNotifications(callback) {
  const sql = `DELETE FROM notifications WHERE created < (strftime('%s', 'now') - 604800)`;
  sqlQuery(sql, [], function (sqlResp) {
    if (callback) callback(sqlResp);
  });
}

function checkTransactionProcessed(coinId, callback) {
  const sql = `SELECT coin_id FROM processed_transactions WHERE coin_id = ?`;
  sqlQuery(sql, [coinId], function (sqlResp) {
    if (callback) {
      callback(sqlResp.status && sqlResp.count > 0);
    }
  });
}

function markTransactionProcessed(coinId, transactionType, recipientAddress, amount, relatedId, callback) {
  // First, check if we need to limit the table to 100 entries
  const countSQL = `SELECT COUNT(*) as count FROM processed_transactions`;
  sqlQuery(countSQL, [], function (countResp) {
    if (countResp.status && countResp.rows && countResp.rows[0].count >= 100) {
      // Delete the oldest record to make room
      const deleteOldestSQL = `DELETE FROM processed_transactions WHERE coin_id IN (
        SELECT coin_id FROM processed_transactions ORDER BY processed_at ASC LIMIT 1
      )`;
      sqlQuery(deleteOldestSQL, [], function (deleteResp) {
        // Now insert the new record
        insertNewTransaction();
      });
    } else {
      // Insert directly if under 100 records
      insertNewTransaction();
    }
  });

  function insertNewTransaction() {
    const currentTime = Math.floor(Date.now() / 1000);
    const sql = `INSERT INTO processed_transactions (coin_id, transaction_type, processed_at, recipient_address, amount, related_id) 
                 VALUES (?, ?, ?, ?, ?, ?)`;
    sqlQuery(sql, [coinId, transactionType, currentTime, recipientAddress, amount, relatedId], function (sqlResp) {
      if (callback) callback(sqlResp);
    });
  }
}

function getProcessedTransactionsByAddress(recipientAddress, callback) {
  let sql, params;
  
  if (recipientAddress) {
    // Query by specific address
    sql = `SELECT coin_id, transaction_type, processed_at, recipient_address, amount, related_id 
           FROM processed_transactions 
           WHERE recipient_address = ? 
           ORDER BY processed_at DESC`;
    params = [recipientAddress];
  } else {
    // Return all entries
    sql = `SELECT coin_id, transaction_type, processed_at, recipient_address, amount, related_id 
           FROM processed_transactions 
           ORDER BY processed_at DESC`;
    params = [];
  }
  
  sqlQuery(sql, params, function (sqlResp) {
    if (callback) callback(sqlResp);
  });
}

function updateTotalReceivedPayments(userPubkey, amount, callback) {
  const sql = `UPDATE user_preferences 
               SET total_received_payments = total_received_payments + ? 
               WHERE user_pubkey = ?`;

  // Ensure amount is converted to a number
  const numericAmount = Number(amount) || 0;

  sqlQuery(sql, [numericAmount, userPubkey], function(sqlResp) {
    if (callback) callback(sqlResp);
  });
}

function getTotalReceivedPayments(userPubkey, callback) {
  const sql = `SELECT total_received_payments FROM user_preferences 
               WHERE user_pubkey = ?`;

  sqlQuery(sql, [userPubkey], function(sqlResp) { 
    if (callback) {
      const total = sqlResp.rows && sqlResp.rows.length > 0 ? 
        sqlResp.rows[0].TOTAL_RECEIVED_PAYMENTS || 0 : 0;
      callback(total);
    }
  });
}

function checkReplyExists(replyId, callback) {
  const checkReplySQL = `SELECT reply_id FROM replies WHERE reply_id = ?`;
  sqlQuery(checkReplySQL, [replyId], function (sqlResp) {
    callback(sqlResp.status && sqlResp.count > 0);
  });
}

function getParentPostReplyCount(parentPostId, callback) {
  const sql = `SELECT reply_count FROM vox_posts WHERE post_id = ?`;
  
  sqlQuery(sql, [parentPostId], function (sqlResp) {
    if (sqlResp.status && sqlResp.rows.length > 0) {
      callback(sqlResp.rows[0].REPLY_COUNT || 0);
    } else {
      callback(0);
    }
  });
}

// Attach user management functions to window for global access (browser context only)
// Check if window exists to avoid errors in Minima dApp environment
if (typeof window !== 'undefined') {
  window.followUser = followUser;
  window.unFollowUser = unFollowUser;
  window.blockUser = blockUser;
  window.unBlockUser = unBlockUser;
  window.checkUserSubscribed = checkUserSubscribed;
  window.checkUserBlocked = checkUserBlocked;
  window.getAllSubscribedUsers = getAllSubscribedUsers;
  window.getAllBlockedUsers = getAllBlockedUsers;
  // Aliases for compatibility
  window.subscribeUser = followUser;
  window.unsubscribeUser = unFollowUser;
  // Expose new post+reply query functions
  window.getAllPostsWithReplies = getAllPostsWithReplies;
  window.getAllPostsBySubscribedUsersWithReplies = getAllPostsBySubscribedUsersWithReplies;
  window.getPostsBySubvWithReplies = getPostsBySubvWithReplies;
  window.getParentPostReplyCount = getParentPostReplyCount;
  // Expose payment functions
  window.getTotalReceivedPayments = getTotalReceivedPayments;
  window.updateTotalReceivedPayments = updateTotalReceivedPayments;
}

function getAllPostsWithReplies(callback) {
  const sql = `
    SELECT 
      p.POST_ID as id,
      p.USER_PUBKEY,
      p.USER_ADDRESS,
      p.MESSAGE,
      p.TITLE,
      p.CREATED,
      p.TOTAL_TIPS,
      p.CATEGORY,
      p.SUBV,
      p.REPLY_COUNT,
      p.LAST_REPLY_TIME,
      up.USER_NAME,
      'POST' as item_type,
      NULL as parent_post_id
    FROM vox_posts p
    LEFT JOIN user_profiles up ON p.user_pubkey = up.user_pubkey
    WHERE (up.is_blocked = 0 OR up.is_blocked IS NULL)
    
    UNION ALL
    
    SELECT 
      r.REPLY_ID as id,
      r.USER_PUBKEY,
      r.USER_ADDRESS,
      r.MESSAGE,
      NULL as title,
      r.CREATED,
      r.TOTAL_TIPS,
      'REPLY' as category,
      p.SUBV as subv,
      0 as reply_count,
      NULL as last_reply_time,
      up.USER_NAME,
      'REPLY' as item_type,
      r.PARENT_POST_ID as parent_post_id
    FROM replies r
    INNER JOIN user_profiles up ON r.user_pubkey = up.user_pubkey
    INNER JOIN vox_posts p ON r.parent_post_id = p.post_id
    WHERE (up.is_blocked = 0 OR up.is_blocked IS NULL)
    
    ORDER BY CREATED DESC`;

  MDS.sql(sql, function (sqlResp) {
    if (sqlResp.status) {
      const results = sqlResp.rows;
      let processedCount = 0;

      if (results.length === 0) {
        callback(sqlResp);
        return;
      }

      results.forEach((row, index) => {
        if (row.CATEGORY === "POLL" && row.ITEM_TYPE === "POST") {
          // Fetch poll options for posts only
          const optionsSql = `SELECT * FROM poll_options WHERE poll_id = ?`;

          sqlQuery(optionsSql, [row.ID], function (optionsResp) {
            if (optionsResp.status) {
              results[index].OPTIONS = optionsResp.rows;

              // Create a structured message for the poll
              const pollData = {
                question: row.MESSAGE,
                options: optionsResp.rows,
              };
              results[index].MESSAGE = JSON.stringify(pollData);
            }

            processedCount++;
            if (processedCount === results.length) {
              callback({
                status: true,
                rows: results,
                count: results.length,
              });
            }
          });
        } else {
          processedCount++;
          if (processedCount === results.length) {
            callback({
              status: true,
              rows: results,
              count: results.length,
            });
          }
        }
      });
    } else {
      callback(sqlResp);
    }
  });
}

function getAllPostsBySubscribedUsersWithReplies(callback) {
  const sql = `SELECT 
    p.POST_ID as id,
    p.USER_PUBKEY,
    p.USER_ADDRESS,
    p.MESSAGE,
    p.TITLE,
    p.CREATED,
    p.TOTAL_TIPS,
    p.CATEGORY,
    p.SUBV,
    p.REPLY_COUNT,
    p.LAST_REPLY_TIME,
    up.USER_NAME,
    'POST' as item_type,
    NULL as parent_post_id
  FROM vox_posts p
  INNER JOIN user_profiles up ON p.user_pubkey = up.user_pubkey
  WHERE up.is_subscribed = 1
  
  UNION ALL
  
  SELECT 
    r.REPLY_ID as id,
    r.USER_PUBKEY,
    r.USER_ADDRESS,
    r.MESSAGE,
    NULL as title,
    r.CREATED,
    r.TOTAL_TIPS,
    'REPLY' as category,
    p.SUBV as subv,
    0 as reply_count,
    NULL as last_reply_time,
    up.USER_NAME,
    'REPLY' as item_type,
    r.PARENT_POST_ID as parent_post_id
  FROM replies r
  INNER JOIN user_profiles up ON r.user_pubkey = up.user_pubkey
  INNER JOIN vox_posts p ON r.parent_post_id = p.post_id
  WHERE up.is_subscribed = 1
  
  ORDER BY CREATED DESC`;

  MDS.sql(sql, function (sqlResp) {
    callback(sqlResp);
  });
}

function getPostsBySubvWithReplies(subv, callback) {
  const sql = `SELECT 
    p.POST_ID as id,
    p.USER_PUBKEY,
    p.USER_ADDRESS,
    p.MESSAGE,
    p.TITLE,
    p.CREATED,
    p.TOTAL_TIPS,
    p.CATEGORY,
    p.SUBV,
    p.REPLY_COUNT,
    p.LAST_REPLY_TIME,
    up.USER_NAME,
    'POST' as item_type,
    NULL as parent_post_id
  FROM vox_posts p
  INNER JOIN user_profiles up ON p.user_pubkey = up.user_pubkey
  WHERE p.subv = ?
  
  UNION ALL
  
  SELECT 
    r.REPLY_ID as id,
    r.USER_PUBKEY,
    r.USER_ADDRESS,
    r.MESSAGE,
    NULL as title,
    r.CREATED,
    r.TOTAL_TIPS,
    'REPLY' as category,
    parent.SUBV as subv,
    0 as reply_count,
    NULL as last_reply_time,
    up.USER_NAME,
    'REPLY' as item_type,
    r.PARENT_POST_ID as parent_post_id
  FROM replies r
  INNER JOIN user_profiles up ON r.user_pubkey = up.user_pubkey
  INNER JOIN vox_posts parent ON r.parent_post_id = parent.post_id
  WHERE parent.subv = ?
  
  UNION ALL
  
  SELECT 
    r.REPLY_ID as id,
    r.USER_PUBKEY,
    r.USER_ADDRESS,
    r.MESSAGE,
    NULL as title,
    r.CREATED,
    r.TOTAL_TIPS,
    'REPLY' as category,
    ? as subv,
    0 as reply_count,
    NULL as last_reply_time,
    up.USER_NAME,
    'REPLY' as item_type,
    r.PARENT_POST_ID as parent_post_id
  FROM replies r
  INNER JOIN user_profiles up ON r.user_pubkey = up.user_pubkey
  WHERE r.message LIKE ?
  
  ORDER BY CREATED DESC`;

  sqlQuery(sql, [subv, subv, subv, `%v/${subv}%`], function (sqlResp) {
    callback(sqlResp);
  });
}








